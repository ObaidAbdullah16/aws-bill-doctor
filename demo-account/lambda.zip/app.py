def handler(event, context):
    """Demo function for the security check sample. Does nothing."""
    return {"ok": True}
